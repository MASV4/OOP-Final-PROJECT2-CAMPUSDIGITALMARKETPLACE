package campusdigitalmarket.models;

public class Product {
    private int    productId;
    private String productName;
    private String description;
    private double price;
    private int    stockQuantity;
    private String category;
    private byte[] productImage;

    public Product() {}

    public Product(int productId, String productName, double price,
                   int stockQuantity, String category) {
        this.productId     = productId;
        this.productName   = productName;
        this.price         = price;
        this.stockQuantity = stockQuantity;
        this.category      = category;
    }

    // Getters
    public int    getProductId()     { return productId; }
    public String getProductName()   { return productName; }
    public String getDescription()   { return description; }
    public double getPrice()         { return price; }
    public int    getStockQuantity() { return stockQuantity; }
    public String getCategory()      { return category; }
    public byte[] getProductImage()  { return productImage; }

    // Setters
    public void setProductId(int v)       { this.productId = v; }
    public void setProductName(String v)  { this.productName = v; }
    public void setDescription(String v)  { this.description = v; }
    public void setPrice(double v)        { this.price = v; }
    public void setStockQuantity(int v)   { this.stockQuantity = v; }
    public void setCategory(String v)     { this.category = v; }
    public void setProductImage(byte[] v) { this.productImage = v; }

    @Override
    public String toString() {
        return productName + " - P" + String.format("%.2f", price);
    }
}
