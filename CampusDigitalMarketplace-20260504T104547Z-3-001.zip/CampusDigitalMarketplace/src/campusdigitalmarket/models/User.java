package campusdigitalmarket.models;

public class User {
    private int    userId;
    private String studentId;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String userLevel;
    private String address;
    private String additionalInfo;
    private byte[] profilePicture;

    public User() {}

    public User(String studentId, String firstName, String lastName,
                String email, String password, String userLevel) {
        this.studentId = studentId;
        this.firstName = firstName;
        this.lastName  = lastName;
        this.email     = email;
        this.password  = password;
        this.userLevel = userLevel;
    }

    // Getters
    public int    getUserId()        { return userId; }
    public String getStudentId()     { return studentId; }
    public String getFirstName()     { return firstName; }
    public String getLastName()      { return lastName; }
    public String getEmail()         { return email; }
    public String getPassword()      { return password; }
    public String getUserLevel()     { return userLevel; }
    public String getAddress()       { return address; }
    public String getAdditionalInfo(){ return additionalInfo; }
    public byte[] getProfilePicture(){ return profilePicture; }
    public String getFullName()      { return firstName + " " + lastName; }

    // Setters
    public void setUserId(int v)           { this.userId = v; }
    public void setStudentId(String v)     { this.studentId = v; }
    public void setFirstName(String v)     { this.firstName = v; }
    public void setLastName(String v)      { this.lastName = v; }
    public void setEmail(String v)         { this.email = v; }
    public void setPassword(String v)      { this.password = v; }
    public void setUserLevel(String v)     { this.userLevel = v; }
    public void setAddress(String v)       { this.address = v; }
    public void setAdditionalInfo(String v){ this.additionalInfo = v; }
    public void setProfilePicture(byte[] v){ this.profilePicture = v; }

    @Override
    public String toString() {
        return "[" + studentId + "] " + getFullName() + " (" + userLevel + ")";
    }
}
