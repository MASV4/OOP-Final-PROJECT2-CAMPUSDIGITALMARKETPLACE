package campusdigitalmarket.models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Order {
    private int          orderId;
    private int          userId;
    private Date         orderDate;
    private double       totalAmount;
    private String       status;
    private List<OrderItem> items;

    public Order() { items = new ArrayList<>(); }

    public Order(int orderId, int userId, Date orderDate,
                 double totalAmount, String status) {
        this.orderId     = orderId;
        this.userId      = userId;
        this.orderDate   = orderDate;
        this.totalAmount = totalAmount;
        this.status      = status;
        this.items       = new ArrayList<>();
    }

    // Getters
    public int              getOrderId()     { return orderId; }
    public int              getUserId()      { return userId; }
    public Date             getOrderDate()   { return orderDate; }
    public double           getTotalAmount() { return totalAmount; }
    public String           getStatus()      { return status; }
    public List<OrderItem>  getItems()       { return items; }

    // Setters
    public void setOrderId(int v)          { this.orderId = v; }
    public void setUserId(int v)           { this.userId = v; }
    public void setOrderDate(Date v)       { this.orderDate = v; }
    public void setTotalAmount(double v)   { this.totalAmount = v; }
    public void setStatus(String v)        { this.status = v; }
    public void setItems(List<OrderItem> v){ this.items = v; }

    public void addItem(OrderItem i)       { items.add(i); }
}
