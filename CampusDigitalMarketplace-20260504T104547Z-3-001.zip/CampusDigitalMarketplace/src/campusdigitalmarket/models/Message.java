package campusdigitalmarket.models;

import java.util.Date;

public class Message {
    private int    messageId;
    private int    senderId;
    private int    receiverId;
    private String senderName;
    private String content;
    private Date   sentAt;
    private boolean isRead;

    public Message() {}

    public Message(int senderId, int receiverId, String content) {
        this.senderId   = senderId;
        this.receiverId = receiverId;
        this.content    = content;
    }

    // Getters
    public int     getMessageId()  { return messageId; }
    public int     getSenderId()   { return senderId; }
    public int     getReceiverId() { return receiverId; }
    public String  getSenderName() { return senderName; }
    public String  getContent()    { return content; }
    public Date    getSentAt()     { return sentAt; }
    public boolean isRead()        { return isRead; }

    // Setters
    public void setMessageId(int v)      { this.messageId = v; }
    public void setSenderId(int v)       { this.senderId = v; }
    public void setReceiverId(int v)     { this.receiverId = v; }
    public void setSenderName(String v)  { this.senderName = v; }
    public void setContent(String v)     { this.content = v; }
    public void setSentAt(Date v)        { this.sentAt = v; }
    public void setRead(boolean v)       { this.isRead = v; }
}
