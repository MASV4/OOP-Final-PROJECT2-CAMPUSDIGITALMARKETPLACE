package campusdigitalmarket.models;

public class OrderItem {
    private int    itemId;
    private int    orderId;
    private int    productId;
    private String productName;
    private int    quantity;
    private double unitPrice;

    public OrderItem() {}

    public OrderItem(int productId, String productName,
                     int quantity, double unitPrice) {
        this.productId   = productId;
        this.productName = productName;
        this.quantity    = quantity;
        this.unitPrice   = unitPrice;
    }

    // Getters
    public int    getItemId()      { return itemId; }
    public int    getOrderId()     { return orderId; }
    public int    getProductId()   { return productId; }
    public String getProductName() { return productName; }
    public int    getQuantity()    { return quantity; }
    public double getUnitPrice()   { return unitPrice; }
    public double getSubtotal()    { return quantity * unitPrice; }

    // Setters
    public void setItemId(int v)        { this.itemId = v; }
    public void setOrderId(int v)       { this.orderId = v; }
    public void setProductId(int v)     { this.productId = v; }
    public void setProductName(String v){ this.productName = v; }
    public void setQuantity(int v)      { this.quantity = v; }
    public void setUnitPrice(double v)  { this.unitPrice = v; }
}
