package campusdigitalmarket.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL =
        "jdbc:derby:./CampusDigitalMarketDB";

    private static final String USER = "cdm_user";
    private static final String PASS = "cdm_pass";

    private static Connection connection = null;

    private DatabaseConnection() {}

    public static Connection getConnection() {

        try {

            if (connection == null || connection.isClosed()) {

                Class.forName("org.apache.derby.jdbc.EmbeddedDriver");

                connection = DriverManager.getConnection(
                    URL,
                    USER,
                    PASS
                );

                System.out.println("[DB] Embedded Derby connected.");
            }

        } catch (ClassNotFoundException ex) {

            ex.printStackTrace();

        } catch (SQLException ex) {

            ex.printStackTrace();
        }

        return connection;
    }

    public static void closeConnection() {

        try {

            if (connection != null && !connection.isClosed()) {

                connection.close();
            }

        } catch (SQLException ex) {

            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {

        Connection conn = getConnection();

        if (conn != null) {

            System.out.println("SUCCESS: Database connection works!");

        } else {

            System.out.println("FAILED: Database connection failed.");
        }

        closeConnection();
    }
}