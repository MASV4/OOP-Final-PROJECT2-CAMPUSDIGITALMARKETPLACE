package campusdigitalmarket.database;

import campusdigitalmarket.models.User;
import campusdigitalmarket.utils.Passwordutils;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    private Connection conn;

    public UserDAO() {
        // Initializes connection using your helper class
        conn = DatabaseConnection.getConnection();
    }

    // LOGIN METHOD
    public User login(String studentId, String password) {
        String sql = "SELECT * FROM CDM_USER.USERS " +
                     "WHERE STUDENT_ID = ? AND PASSWORD = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, studentId);
            ps.setString(2, Passwordutils.hashPassword(password));
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("Login error: " + e.getMessage());
        }
        return null;
    }

    // GET BY ID
    public User getUserById(int userId) {
        String sql = "SELECT * FROM CDM_USER.USERS WHERE USER_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("Get user error: " + e.getMessage());
        }
        return null;
    }

    // GET ALL USERS
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM CDM_USER.USERS ORDER BY LAST_NAME";
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("Get all users error: " + e.getMessage());
        }
        return list;
    }

    // REGISTER USER
    public boolean registerUser(User user) {
        String sql = "INSERT INTO CDM_USER.USERS " +
                     "(STUDENT_ID, FIRST_NAME, LAST_NAME, EMAIL, PASSWORD, " +
                     "USER_LEVEL, ADDRESS, ADDITIONAL_INFO) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user.getStudentId());
            ps.setString(2, user.getFirstName()); // Fixed missing () from image_aa2535.png
            ps.setString(3, user.getLastName());
            ps.setString(4, user.getEmail());
            ps.setString(5, Passwordutils.hashPassword(user.getPassword()));
            ps.setString(6, user.getUserLevel());
            ps.setString(7, user.getAddress());
            ps.setString(8, user.getAdditionalInfo());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Register error: " + e.getMessage());
            return false;
        }
    }

    // HELPER METHOD (This resolves the "cannot find symbol" errors in your images)
    private User mapRow(ResultSet rs) throws SQLException {
        User user = new User();
        user.setStudentId(rs.getString("STUDENT_ID"));
        user.setFirstName(rs.getString("FIRST_NAME"));
        user.setLastName(rs.getString("LAST_NAME"));
        user.setEmail(rs.getString("EMAIL"));
        // Add additional setters here based on your User model fields
        return user;
    }
}