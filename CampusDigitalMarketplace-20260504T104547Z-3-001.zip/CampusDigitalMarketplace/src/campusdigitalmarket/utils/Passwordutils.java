package campusdigitalmarket.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Passwordutils {

    private Passwordutils() {}

    /** Hashes password using SHA-256 */
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    public static boolean verifyPassword(String plainText, String hashed) {
        return hashPassword(plainText).equals(hashed);
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.trim().length() >= 6;
    }
}
