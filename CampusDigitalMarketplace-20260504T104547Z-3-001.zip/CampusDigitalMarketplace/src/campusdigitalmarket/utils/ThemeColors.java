package campusdigitalmarket.utils;

import java.awt.Color;
import java.awt.Font;
import java.awt.Dimension;

/**
 * Strictly follows the UI specifications for Campus Digital Market.
 * Colors: [0,0,51] Primary
 * Font: Segoe UI
 */
public class ThemeColors {

    // ── Primary UI Colors ──────────────────────────────────────────
    // Based on the dark sidebar and button theme
    public static final Color UI_PRIMARY      = new Color(0, 0, 51);   
    public static final Color WHITE           = new Color(255, 255, 255);
    public static final Color MAIN_BG         = new Color(245, 246, 255);
    public static final Color SIDEBAR_BG      = UI_PRIMARY;
    
    // ── Status & Accent Colors ─────────────────────────────────────
    public static final Color PURPLE_ACCENT   = new Color(130, 80, 250); // For icons and highlights
    public static final Color SUCCESS         = new Color(34, 160, 74);
    public static final Color DANGER          = new Color(210, 50, 65);

    // ── Fonts ──────────────────────────────────────────────────────
    // Strict requirements for Brand and Buttons
    public static final Font FONT_BRAND       = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font FONT_BUTTON      = new Font("Segoe UI", Font.BOLD, 18);
    
    // General UI Fonts
    public static final Font FONT_SUBTITLE    = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font FONT_BODY        = new Font("Segoe UI", Font.PLAIN, 13);

    // ── Dimensions ──────────────────────────────────────────────────
    // Precise sizes for the Marketplace Logo and Sidebar Icons
    public static final Dimension MARKET_LOGO_SIZE = new Dimension(199, 152);
    public static final Dimension NAV_ICON_SIZE    = new Dimension(41, 39);

    private ThemeColors() {}
}